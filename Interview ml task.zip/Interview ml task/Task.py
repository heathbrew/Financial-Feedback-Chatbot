#!/usr/bin/env python
# coding: utf-8

# Preprocessing

# In[2]:


import numpy as np
import pandas as pd
import re
import nltk
nltk.download('stopwords')
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

def preprocess(text):
    # Remove special characters, numbers and punctuations
    text = re.sub(r'[^a-zA-Z\s]', '', text, re.I|re.A)
    
    # Convert text to lowercase
    text = text.lower()
    
    # Tokenize the text
    words = word_tokenize(text)
    
    # Remove stop words
    stop_words = set(stopwords.words("english"))
    words = [word for word in words if word not in stop_words]
    
    return " ".join(words)

df = pd.read_csv("FF_dataset - Sheet1.csv")
df['notes'] = df['notes'].apply(lambda x: preprocess(x))


# extractive summarization

# In[18]:


from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

def summarize_text(text, n):
    sentences = text.split(".")
    tfidf = TfidfVectorizer()
    tfidf_matrix = tfidf.fit_transform(sentences)
    similarity_matrix = cosine_similarity(tfidf_matrix)
    scores = np.array(similarity_matrix.sum(axis=0)).flatten()
    top_sentence_indices = scores.argsort()[-n:]
    top_sentences = [sentences[i] for i in sorted(top_sentence_indices)]
    summarized_text = " ".join(top_sentences)
    return summarized_text

text = "36-year-old engineer, been working there for 5 years, about to move back to UK for family reasons. Own a property about to sell. Non-qualified pension with EFA organisation, €120k in there (more of an investment fund rather than a pension), already an agreement with French tax authorities who won’t tax the income from salary but will tax the capital gains (but quite small). Still French resident, in the UK on 6th April 2023 for tax provisionally and physically moving back around 15th February. Significant gain on French property but should be tax-free. Can close pension when off payroll which should be end of Feb but could be end of March."
summarized_text = summarize_text(text,3)
print("Summarized text: ", summarized_text)


# In[29]:


import re
def generate_email(text, country):
    summarized_text = summarize_text(text,3)
    summarized_text = summarized_text.encode('ascii', 'ignore').decode()
    email_template = "Subject:{}\n\nDear [Name],\n\nThank you for providing me with the details of your financial situation. I appreciate the opportunity to offer my expert insights.\n\nBased on the information you've shared, I would like to summarize the key points of your financial situation:\n\n{}\n\n I hope that you find this summary helpful. If you have any further questions or would like to discuss your situation in more detail, please don't hesitate to reach out.\n\nBest regards, [Name]"
    email = email_template.format(summarize_text(text,1),summarized_text)

    return email


# In[30]:


text = "36-year-old engineer, been working there for 5 years, about to move back to UK for family reasons. Own a property about to sell. Non-qualified pension with EFA organization, â‚¬120k in there (more of an investment fund rather than a pension), already an agreement with French tax authorities who wonâ€™t tax the income from salary but will tax the capital gains (but quite small). Still French resident, in the UK on 6th April 2023 for tax provisionally and physically moving back around 15th February. Significant gain on French property but should be tax-free. Can close pension when off payroll which should be end of Feb but could be end of March."
country = "UK"

email = generate_email(text, country)
print(email)


# In[32]:


from transformers import pipeline, set_seed

generator = pipeline('text-generation', model='openai-gpt')
set_seed(42)
generator("give bullet Positive Points in "+ summarize_text(text,3), max_length=30, num_return_sequences=5)


# In[ ]:




