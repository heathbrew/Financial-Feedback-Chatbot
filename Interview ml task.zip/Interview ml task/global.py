message = "Error"
y = int(input())
if y == 0:
    message = "no error"
print(message)
