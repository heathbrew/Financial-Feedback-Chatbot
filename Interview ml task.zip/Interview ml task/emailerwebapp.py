import smtplib, ssl
import streamlit as st

port = 587  # For starttls
smtp_server = "smtp.gmail.com"

sender_email = st.text_input("Enter your mail id:")
password = st.text_input("Enter your password:")
#enter your app password - pqdngcgjltavgspx
receiver_email = st.text_input("Enter receiver's mail id:")

message = st.text_area("Enter your message:", "", key='query', height=200)

context = ssl.create_default_context()




with smtplib.SMTP(smtp_server, port) as server:
    server.ehlo()  # Can be omitted
    server.starttls(context=context)
    server.ehlo()  # Can be omitted
    
    if st.button("Send") :
        server.login(sender_email, password)
        server.sendmail(sender_email, receiver_email, message)