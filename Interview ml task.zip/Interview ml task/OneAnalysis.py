#!/usr/bin/env python
# coding: utf-8

# In[63]:


import numpy as np
import pandas as pd
import re
import nltk
nltk.download('stopwords')
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import openai
import os
import nltk
from nltk.sentiment import SentimentIntensityAnalyzer


# In[64]:


def preprocess(text):
    # Remove special characters, numbers and punctuations
    text = re.sub(r'[^a-zA-Z\s]', '', text, re.I|re.A)
    
    # Convert text to lowercase
    text = text.lower()
    
    # Tokenize the text
    words = word_tokenize(text)
    
    # Remove stop words
    stop_words = set(stopwords.words("english"))
    words = [word for word in words if word not in stop_words]
    
    return " ".join(words)

def extractive_summarize_text(text, n):
    sentences = text.split(".")
    tfidf = TfidfVectorizer()
    tfidf_matrix = tfidf.fit_transform(sentences)
    similarity_matrix = cosine_similarity(tfidf_matrix)
    scores = np.array(similarity_matrix.sum(axis=0)).flatten()
    top_sentence_indices = scores.argsort()[-n:]
    top_sentences = [sentences[i] for i in sorted(top_sentence_indices)]
    summarized_text = " ".join(top_sentences)
    return summarized_text

# Create a function that generates a response to a user's query
def generate_response(prompt):
    openai.api_key = api_key
    response = openai.Completion.create(
        engine="text-davinci-003",
        # engine="davinci", 	
        prompt= "<|endoftext|>"+ prompt +"\n--\nLabel:",
        # max_tokens=687,
        max_tokens= 256,
        temperature=0.5,
        top_p=1
        #0.22,0.83 , 63 stop
        # 0.22,0.91, 70 - stop
    )
    return response["choices"][0]["text"]

api_key = os.environ["OPENAI_API_KEY"] = "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"
if api_key is None:
    raise ValueError("Please set the OPENAI_API_KEY environment variable.")
    
def generate_email(sentiments):
    positive_text = [sentence for sentiment, sentence in sentiments if sentiment == "Positive"]
    negative_text = [sentence for sentiment, sentence in sentiments if sentiment == "Negative"]
    neutral_text = [sentence for sentiment, sentence in sentiments if sentiment == "Neutral/Recommendation"]

    positive_text = "\n".join(positive_text)
    negative_text = "\n".join(negative_text)
    neutral_text = "\n".join(neutral_text)

    email_template = "Subject: {}\n\nDear [Name],\n\nThank you for providing me with the details of your financial situation. I appreciate the opportunity to offer my expert insights.\n\nBased on the information you've shared, I would like to summarize the key points of your financial situation:\n\n{}\n\n{}\n\n{}\n\n I hope that you find this summary helpful. If you have any further questions or would like to discuss your situation in more detail, please don't hesitate to reach out.\n\nBest regards, [Name]"
    email = email_template.format(summarize_text(text,1),positive_text, negative_text, neutral_text)

    return email

def get_sentiments(text):
    nltk.download("vader_lexicon")
    sia = SentimentIntensityAnalyzer()
    sentiments = []
    for sentence in nltk.sent_tokenize(text):
        pol_score = sia.polarity_scores(sentence)
        if pol_score['compound'] > 0.05:
            sentiments.append(('Positive', sentence))
        elif pol_score['compound'] < -0.05:
            sentiments.append(('Negative', sentence))
        else:
            sentiments.append(('Neutral/Recommendation', sentence))
    return sentiments


# In[65]:


text = "36-year-old engineer, been working there for 5 years, about to move back to UK for family reasons. Own a property about to sell. Non-qualified pension with EFA organisation, €120k in there (more of an investment fund rather than a pension), already an agreement with French tax authorities who won’t tax the income from salary but will tax the capital gains (but quite small). Still French resident, in the UK on 6th April 2023 for tax provisionally and physically moving back around 15th February. Significant gain on French property but should be tax-free. Can close pension when off payroll which should be end of Feb but could be end of March."
Prompt = """give comments with respect to 
1.investment - should be 40% of total income 
2.insurance - should be 10% of total income 
3.side hustle/entrepeneurial venture - should be 20% of total income 
4. tax - should be 10% of total income 
5.risk/crisis - should be 10% of total income 
6.purchases - should be 10% of total income 
being used as headers for """
country = "UK"
summarized_text = generate_response("For Citizens of"+country +Prompt+str(extractive_summarize_text(text,3)))
# print("Summarized text: ", summarized_text)


# In[66]:


sentiments = get_sentiments(summarized_text)
# print(sentiments)


# In[67]:


email=generate_email(sentiments)
print(email)


# In[ ]:




