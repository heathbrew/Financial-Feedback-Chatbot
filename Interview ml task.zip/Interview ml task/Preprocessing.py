#!/usr/bin/env python
# coding: utf-8

# In[3]:


import csv
import pandas as pd

# Read data from input.xlsx file
data = pd.read_csv('FF_dataset - Sheet1.csv')
data.head()


# In[4]:


import os
# Create a new directory called "extract"
if not os.path.exists("email"):
    os.makedirs("email")


# In[12]:


# # Iterate over each row in the data
# for i in range(0,len(data)):
#     print(row[i])
    
# for index, row in data.iterrows():
#     print(row[index])
    
#     notes = row['notes']
#     email summary = row['email summary']
#     country = row["country"]
#     print(notes,email summary,country)
    
#     if not os.path.exists("extract/{url_id}.txt"):
#         content = str(try_again(url))
#         if content == "skip":
#              with open(f'extract/{url_id}.txt', 'w') as f:
#                     f.write("")
#         else:
#             # Save the extracted article text to a file with the URL_ID as its file name
#                 with open(f'extract/{url_id}.txt', 'w') as f:
#                     ascii_text = content.encode('ascii', 'ignore').decode()
#                     f.write(ascii_text)


# In[16]:


file = 'FF_dataset - Sheet1.csv' # Target CSV file path
with open(file, newline='', encoding='utf-8') as f:
    reader = csv.reader(f)
    data = list(reader)
datalist = list(data)
index = []
notes =[]
summary =[]
country =[]
datas = []
for i in range(0,len(datalist)):
    index.append(i)
    notes.append(datalist[i][0])
    summary.append(datalist[i][1])
    country.append(datalist[i][2])
    datas.append([notes,summary,country])
fetcher = {}
for i in range(len(index)):
    fetcher[index[i]] = datas[i]
# print(fetcher)


# In[ ]:




